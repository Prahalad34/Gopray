import 'package:flutter/material.dart';

class Appcolor {
  static const PrimaryColor =  Color(0xFF4190DB);
  static const PrimaryColor1 =  Color(0xFFF7D18D);
  static const PrimaryColor2 =  Color(0xFFDDC979);
  static const PrimaryColor3 =  Color(0xFFF1F1F1);
  static const PrimaryColor4 =  Color(0xFFFFFFFF);
  static const PrimaryColor5 =  Color(0xFF919191);
  static const PrimaryColor6 =  Color(0xFFF8F8F8);
  static const PrimaryColor7 =  Color(0xFFF8F8F8);
  static const PrimaryColor8 =  Color(0xFF2E669B);
  static const PrimaryColor9 =  Color(0xFFE53535);
  static const PrimaryColor10 =  Color(0xFF4190DB);
  static const PrimaryColor11 =  Color(0xFF2563EB);
  static const PrimaryColor12 =  Color(0xFFF2F2F2);
  static const PrimaryColor13 =  Color(0xFFECFDF3);
  static const PrimaryColor14 =  Color(0xFF027948);
  static const PrimaryColor15 =  Color(0xFF767676);
  static const PrimaryColor16 =  Color(0xFFC0C0C0);
  static const PrimaryColor17 =  Color(0xFFECF4FB);
  static const PrimaryColor18 =  Color(0xFF002951);
  static const PrimaryColor19 =  Color(0xFFECF4FB);
  static const PrimaryColor20 =  Color(0xFFFFFFFF);
  static const PrimaryColor21 =  Color(0xFF545454);
  static const PrimaryColor22 =  Color(0xFF80B5E7);
  static const PrimaryColor23 =  Color(0xFFECF4FB);
  static const PrimaryColor24 =  Color(0xFFA3A3A3);
  static const PrimaryColor25 =  Color(0xFF3B83C7);


}