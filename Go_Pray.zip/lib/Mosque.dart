import 'package:flutter/material.dart';
class Mosque extends StatefulWidget {
  const Mosque({super.key});

  @override
  State<Mosque> createState() => _MosqueState();
}

class _MosqueState extends State<Mosque> {
  @override
  Widget build(BuildContext context) {
    return const Placeholder();
  }
}
